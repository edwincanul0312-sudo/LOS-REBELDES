# LOS REBELDES — Suite V1

Tres aplicaciones independientes con rol fijo:

1. LOS REBELDES — Cliente
2. LOS REBELDES — Transportista
3. LOS REBELDES — Administrador

Cada aplicación tiene su propio applicationId y no muestra un selector de roles.

Esta V1 es la base de interfaz. La siguiente fase conecta autenticación real, base de datos, GPS, notificaciones, asignación de servicios y tarifas.
