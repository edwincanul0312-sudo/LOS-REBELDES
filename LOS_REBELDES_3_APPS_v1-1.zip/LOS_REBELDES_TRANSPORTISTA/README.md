# LOS REBELDES — Transportista

Aplicación exclusiva para conductores autorizados.

Aplicación independiente de LOS REBELDES.

- Rol fijo: DRIVER
- Sin selector de roles.
- El cliente puede registrarse.
- Transportistas y administradores deben ser dados de alta por el sistema administrativo en la versión conectada al backend.
