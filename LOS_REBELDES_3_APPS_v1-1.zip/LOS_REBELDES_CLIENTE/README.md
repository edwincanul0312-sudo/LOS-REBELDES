# LOS REBELDES — Cliente

Aplicación para solicitar y consultar servicios de mototaxi.

Aplicación independiente de LOS REBELDES.

- Rol fijo: CLIENT
- Sin selector de roles.
- El cliente puede registrarse.
- Transportistas y administradores deben ser dados de alta por el sistema administrativo en la versión conectada al backend.
