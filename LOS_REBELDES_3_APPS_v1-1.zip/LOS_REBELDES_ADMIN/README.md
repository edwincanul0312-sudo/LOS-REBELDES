# LOS REBELDES — Administrador

Aplicación exclusiva para administrar la operación.

Aplicación independiente de LOS REBELDES.

- Rol fijo: ADMIN
- Sin selector de roles.
- El cliente puede registrarse.
- Transportistas y administradores deben ser dados de alta por el sistema administrativo en la versión conectada al backend.
