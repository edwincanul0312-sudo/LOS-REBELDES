package com.losrebeldes.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF101010)
private val Blue = Color(0xFFD6A62A)
private val Green = Color(0xFF218739)
private val Bg = Color(0xFFF5F7FA)

enum class Role { CLIENT, DRIVER, ADMIN }

data class Service(val id:Int, val status:String, val origin:String, val destination:String, val driver:String? = null, val vehicle:String? = null, val total:String? = null)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { RutaApp() } }
}

@Composable fun RutaApp() {
    var logged by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = lightColorScheme(primary=Blue, background=Bg)) {
        Surface(Modifier.fillMaxSize(), color=Bg) {
            if (!logged) LoginScreen(Role.ADMIN, onBack={}, onRegister={}, onLogin={logged=true})
            else AdminHome(onLogout={logged=false})
        }
    }
}

@Composable fun Header(title:String, subtitle:String?=null, onBack:(()->Unit)?=null) {
    Row(Modifier.fillMaxWidth().background(Navy).padding(20.dp), verticalAlignment=Alignment.CenterVertically) {
        if(onBack!=null) IconButton(onClick=onBack) { Icon(Icons.Default.ArrowBack, null, tint=Color.White) }
        Column(Modifier.weight(1f)) { Text(title, color=Color.White, fontSize=24.sp, fontWeight=FontWeight.Bold); subtitle?.let{Text(it,color=Color(0xFFD7E0EF),fontSize=14.sp)} }
        Text("LOS REBELDES", color=Color.White, fontWeight=FontWeight.ExtraBold, fontSize=16.sp)
    }
}

@Composable fun RoleScreen(select:(Role)->Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment=Alignment.CenterHorizontally) {
        Spacer(Modifier.height(48.dp)); Text("LOS REBELDES", fontSize=38.sp, fontWeight=FontWeight.ExtraBold, color=Navy); Text("Mototaxis · Servicio de Transporte", fontSize=17.sp, color=Color.Gray)
        Spacer(Modifier.height(36.dp)); Text("¿Cómo vas a ingresar?", fontSize=22.sp, fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        RoleButton("CLIENTE", "Pedir y consultar servicios", Icons.Default.Person) { select(Role.CLIENT) }
        RoleButton("TRANSPORTISTA", "Recibir y realizar servicios", Icons.Default.DirectionsCar) { select(Role.DRIVER) }
        RoleButton("ADMINISTRADOR", "Controlar la operación", Icons.Default.AdminPanelSettings) { select(Role.ADMIN) }
        Spacer(Modifier.weight(1f)); Text("Servicio sencillo · rápido · de bajo consumo de datos", color=Color.Gray, fontSize=13.sp)
    }
}

@Composable fun RoleButton(title:String, sub:String, icon:androidx.compose.ui.graphics.vector.ImageVector, click:()->Unit) {
    Card(Modifier.fillMaxWidth().padding(vertical=6.dp).clickable{click()}, shape=RoundedCornerShape(18.dp), colors=CardDefaults.cardColors(containerColor=Color.White), elevation=CardDefaults.cardElevation(2.dp)) {
        Row(Modifier.padding(18.dp), verticalAlignment=Alignment.CenterVertically) { Icon(icon,null,tint=Blue,modifier=Modifier.size(38.dp)); Spacer(Modifier.width(16.dp)); Column{Text(title,fontWeight=FontWeight.Bold,fontSize=18.sp);Text(sub,color=Color.Gray)} }
    }
}

@Composable fun LoginScreen(role:Role,onBack:()->Unit,onRegister:()->Unit,onLogin:()->Unit) {
    var phone by remember{mutableStateOf("")}; var pass by remember{mutableStateOf("")}; var rememberMe by remember{mutableStateOf(true)}
    Column(Modifier.fillMaxSize()) {
        Header("Iniciar sesión", when(role){Role.CLIENT->"Cliente";Role.DRIVER->"Transportista";else->"Administrador"}, onBack)
        Column(Modifier.padding(24.dp)) {
            Spacer(Modifier.height(28.dp)); Text("Teléfono",fontWeight=FontWeight.Bold); OutlinedTextField(phone,{phone=it},Modifier.fillMaxWidth(),singleLine=true,leadingIcon={Icon(Icons.Default.Phone,null)})
            Spacer(Modifier.height(14.dp)); Text("Contraseña",fontWeight=FontWeight.Bold); OutlinedTextField(pass,{pass=it},Modifier.fillMaxWidth(),singleLine=true,visualTransformation=PasswordVisualTransformation(),leadingIcon={Icon(Icons.Default.Lock,null)})
            Row(verticalAlignment=Alignment.CenterVertically){Checkbox(rememberMe,{rememberMe=it});Text("Mantener mi sesión iniciada")}
            Spacer(Modifier.height(18.dp)); Button(onClick=onLogin,Modifier.fillMaxWidth().height(56.dp),shape=RoundedCornerShape(14.dp)){Text("ENTRAR",fontSize=18.sp,fontWeight=FontWeight.Bold)}
            if(role==Role.CLIENT){TextButton(onClick=onRegister,Modifier.fillMaxWidth()){Text("Crear cuenta nueva",fontSize=16.sp)}}
        }
    }
}

@Composable fun RegisterScreen(onBack:()->Unit,onDone:()->Unit){
    var name by remember{mutableStateOf("")};var phone by remember{mutableStateOf("")};var pass by remember{mutableStateOf("")};var confirm by remember{mutableStateOf("")}
    Column(Modifier.fillMaxSize()){Header("Crear cuenta","Cliente",onBack);Column(Modifier.padding(24.dp)){Text("Tus datos",fontSize=22.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(14.dp));
        OutlinedTextField(name,{name=it},Modifier.fillMaxWidth(),singleLine=true,label={Text("Nombre")},leadingIcon={Icon(Icons.Default.Person,null)});Spacer(Modifier.height(10.dp));
        OutlinedTextField(phone,{phone=it},Modifier.fillMaxWidth(),singleLine=true,label={Text("Teléfono")},leadingIcon={Icon(Icons.Default.Phone,null)});Spacer(Modifier.height(10.dp));
        OutlinedTextField(pass,{pass=it},Modifier.fillMaxWidth(),singleLine=true,label={Text("Contraseña")},visualTransformation=PasswordVisualTransformation());Spacer(Modifier.height(10.dp));
        OutlinedTextField(confirm,{confirm=it},Modifier.fillMaxWidth(),singleLine=true,label={Text("Repetir contraseña")},visualTransformation=PasswordVisualTransformation());Spacer(Modifier.height(20.dp));
        Button(onClick=onDone,Modifier.fillMaxWidth().height(56.dp),shape=RoundedCornerShape(14.dp)){Text("CREAR CUENTA",fontSize=17.sp,fontWeight=FontWeight.Bold)}
    }}
}

@Composable fun ClientHome(onLogout:()->Unit){
    var screen by remember{mutableStateOf("home")};var requested by remember{mutableStateOf(false)}
    if(screen=="request"){RequestService(onBack={screen="home"},onRequested={requested=true;screen="home"}) ;return}
    if(screen=="services"){ServiceList(onBack={screen="home"});return}
    Column(Modifier.fillMaxSize()){Header("Hola, cliente","Tu transporte cuando lo necesites")
        Column(Modifier.padding(20.dp)){Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Blue)){Column(Modifier.padding(22.dp)){Text("¿Necesitas transporte?",color=Color.White,fontSize=21.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));Button(onClick={screen="request"},Modifier.fillMaxWidth().height(68.dp),colors=ButtonDefaults.buttonColors(containerColor=Color.White,contentColor=Blue),shape=RoundedCornerShape(15.dp)){Text("PEDIR SERVICIO",fontSize=20.sp,fontWeight=FontWeight.ExtraBold)}}}
            Spacer(Modifier.height(18.dp)); HomeAction("Mis servicios",Icons.Default.History){screen="services"};HomeAction("Mi cuenta",Icons.Default.Person){};HomeAction("Ayuda",Icons.Default.HelpOutline){}
            if(requested){Spacer(Modifier.height(14.dp));Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Color(0xFFE8F5E9))){Text("✓ Solicitud enviada. Buscando transportista cercano...",Modifier.padding(16.dp),fontWeight=FontWeight.Bold,color=Green)}}
            Spacer(Modifier.height(18.dp));OutlinedButton(onClick=onLogout,Modifier.fillMaxWidth()){Text("Cerrar sesión")}
        }}
}

@Composable fun HomeAction(t:String,icon:androidx.compose.ui.graphics.vector.ImageVector,click:()->Unit){Card(Modifier.fillMaxWidth().padding(vertical=5.dp).clickable{click()},shape=RoundedCornerShape(14.dp)){Row(Modifier.padding(17.dp),verticalAlignment=Alignment.CenterVertically){Icon(icon,null,tint=Blue);Spacer(Modifier.width(14.dp));Text(t,fontSize=18.sp,fontWeight=FontWeight.SemiBold);Spacer(Modifier.weight(1f));Icon(Icons.Default.ChevronRight,null)}}}

@Composable fun RequestService(onBack:()->Unit,onRequested:()->Unit){var ref by remember{mutableStateOf("")};var dest by remember{mutableStateOf("")};var noDest by remember{mutableStateOf(true)}
    Column(Modifier.fillMaxSize()){Header("Pedir servicio","Recogida",onBack);LazyColumn(Modifier.padding(20.dp)){item{Text("¿Dónde te recogemos?",fontSize=22.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));Button(onClick={},Modifier.fillMaxWidth().height(54.dp)){Icon(Icons.Default.MyLocation,null);Spacer(Modifier.width(8.dp));Text("USAR MI UBICACIÓN",fontWeight=FontWeight.Bold)};Spacer(Modifier.height(12.dp));OutlinedTextField(ref,{ref=it},Modifier.fillMaxWidth(),label={Text("Referencia (ej. frente a la iglesia)")},minLines=2);Spacer(Modifier.height(20.dp));Text("Destino",fontSize=20.sp,fontWeight=FontWeight.Bold);Row(verticalAlignment=Alignment.CenterVertically){Checkbox(noDest,{noDest=it});Text("Le diré mi destino al conductor")};if(!noDest){OutlinedTextField(dest,{dest=it},Modifier.fillMaxWidth(),label={Text("¿A dónde vas?")})};Spacer(Modifier.height(22.dp));Button(onClick=onRequested,Modifier.fillMaxWidth().height(60.dp),shape=RoundedCornerShape(14.dp)){Text("SOLICITAR TRANSPORTE",fontSize=18.sp,fontWeight=FontWeight.Bold)}}}}
}

@Composable fun ServiceList(onBack:()->Unit){val list=listOf(Service(1,"COMPLETADO","Centro","Mercado","Carlos","Nissan NP300","$15.00"),Service(2,"CANCELADO","Barrio Norte","—"));Column(Modifier.fillMaxSize()){Header("Mis servicios",onBack=onBack);LazyColumn(Modifier.padding(18.dp)){items(list){s->Card(Modifier.fillMaxWidth().padding(vertical=6.dp)){Column(Modifier.padding(16.dp)){Text("Servicio #${s.id}",fontWeight=FontWeight.Bold);Text("${s.origin} → ${s.destination}");Text(s.status,fontWeight=FontWeight.Bold,color=if(s.status=="COMPLETADO")Green else Color.Gray);s.total?.let{Text(it,fontSize=18.sp,fontWeight=FontWeight.Bold)}}}}}}
}

@Composable fun DriverHome(onLogout:()->Unit){var active by remember{mutableStateOf(false)};var arrived by remember{mutableStateOf(false)};Column(Modifier.fillMaxSize()){Header("Panel del transportista","Estado: ${if(active)"EN SERVICIO" else "DISPONIBLE"}");Column(Modifier.padding(20.dp)){if(!active){Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(18.dp)){Text("SERVICIO CERCANO",fontSize=21.sp,fontWeight=FontWeight.Bold);Text("A 1.2 km · llegada aprox. 4 min",color=Color.Gray);Text("Recogida: Frente a la iglesia",Modifier.padding(top=10.dp));Text("Destino: Lo indicará el cliente",color=Color.Gray);Spacer(Modifier.height(14.dp));Button(onClick={active=true},Modifier.fillMaxWidth().height(58.dp)){Text("ACEPTAR SERVICIO",fontSize=18.sp,fontWeight=FontWeight.Bold)}}};}else{Text("Servicio #1042",fontSize=24.sp,fontWeight=FontWeight.Bold);Text("Cliente: contacto visible después de aceptar",color=Color.Gray);Spacer(Modifier.height(12.dp));if(!arrived){Button(onClick={arrived=true},Modifier.fillMaxWidth().height(58.dp)){Text("LLEGUÉ",fontSize=19.sp,fontWeight=FontWeight.Bold)}}else{Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Color(0xFFE8F5E9))){Text("✓ Cliente notificado: el transportista llegó",Modifier.padding(16.dp),fontWeight=FontWeight.Bold,color=Green)};Spacer(Modifier.height(14.dp));Text("Pasajeros",fontSize=20.sp,fontWeight=FontWeight.Bold);Text("Adultos: 1   Niños: 0",fontSize=18.sp);Text("Tarifa zona: $10.00",fontSize=18.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(14.dp));Button(onClick={},Modifier.fillMaxWidth().height(55.dp)){Text("INICIAR SERVICIO")};Spacer(Modifier.height(8.dp));OutlinedButton(onClick={active=false;arrived=false},Modifier.fillMaxWidth()){Text("FINALIZAR SERVICIO")}}};Spacer(Modifier.height(25.dp));OutlinedButton(onClick=onLogout,Modifier.fillMaxWidth()){Text("Cerrar sesión")}}}}

@Composable fun AdminHome(onLogout:()->Unit){Column(Modifier.fillMaxSize()){Header("Administración","Control de operación");Column(Modifier.padding(20.dp)){Text("Operación en vivo",fontSize=24.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));Stats("Servicios activos","3");Stats("Transportistas disponibles","7");Stats("Servicios hoy","28");Spacer(Modifier.height(12.dp));HomeAction("Transportistas",Icons.Default.People){};HomeAction("Vehículos",Icons.Default.DirectionsCar){};HomeAction("Zonas y tarifas",Icons.Default.AttachMoney){};HomeAction("Historial y reportes",Icons.Default.Assessment){};Spacer(Modifier.height(16.dp));OutlinedButton(onClick=onLogout,Modifier.fillMaxWidth()){Text("Cerrar sesión")}}}}
@Composable fun Stats(a:String,b:String){Card(Modifier.fillMaxWidth().padding(vertical=4.dp)){Row(Modifier.padding(17.dp)){Text(a,fontSize=17.sp);Spacer(Modifier.weight(1f));Text(b,fontSize=21.sp,fontWeight=FontWeight.ExtraBold,color=Blue)}}}
